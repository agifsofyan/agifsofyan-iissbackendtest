module.exports = {
    uri: 'mongodb://root:57381@127.0.0.1:27017/contactdb?authSource=admin',
    opt: {
		useNewUrlParser: true,
		useUnifiedTopology: true,
		useFindAndModify: false
	}
}